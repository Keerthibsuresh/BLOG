﻿namespace mvcblog.Models
{
    public class blog
    {
        public int BlogId { get; set; }
        public string BlogName { get; set; }

        public string BlogData { get; set; }
    }

    public class BlogOperations
    {
        private static List<blog> _blg = new List<blog>();

        public static int blogId { get; private set; }

        public static List<blog> GetAllblogs()
        {
            if (_blg.Count == 0)
            {
                _blg.Add(new blog() { BlogId= 101, BlogName= "Sports", BlogData="Sports is good for health" });
                
            }
            return _blg;
        }

        internal static void Createblogs(blog b)
        {
            GetAllblogs();
            _blg.Add(b);
        }

        internal static object Search(int blogId)
        {
            return GetAllblogs().Where(b => b.BlogId == blogId).FirstOrDefault();
        }
    }
    }
