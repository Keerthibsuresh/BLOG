﻿using Blog_BL;
using Microsoft.AspNetCore.Mvc;
using mvcblog.Models;

namespace mvcblog.Controllers
{
    public class blogController1 : Controller
    {
        
        [HttpGet("/GetAllblg")]
        public IActionResult GetAllBlogs()
        {
            var Blog = BlogOperations.GetAllblogs();

            return View("blog", Blog);
        }


        [HttpGet("/Createblogs")]
        public IActionResult Createblogs()
        {
            return View("Createblog", new Blog());

        }

        [HttpGet("/Getblog")]
        public IActionResult Getblogs(int BlogId, [FromForm] blog b)
        {
            //call model class method
            var found = BlogOperations.Search(BlogId);

            //return the view with matching person object

            return View("Search", found);
        }
        [HttpPost("/edit/{EmpId}")]
        public IActionResult Edit(int BlogId, [FromForm] blog b)
        {
            var found = BlogOperations.Search(b.BlogId);
            //found.BlogName = b.BlogName;
            //found.BlogData = b.BlogData;
            
            return View("blogList", BlogOperations.GetAllblogs());
        }
        public IActionResult Updateblog()
        {
            return View();
        }

        public IActionResult Insertblog()
        {
            return View();
        }
        public IActionResult Deleteblog()
        {
            return View();
        }

        [HttpGet("/edit/{blogId}")]
        public IActionResult EditBlog(int BlogId)
        {
            var found = BlogOperations.Search(BlogId);
            return View("Editblog", found);
        }
    }
}
