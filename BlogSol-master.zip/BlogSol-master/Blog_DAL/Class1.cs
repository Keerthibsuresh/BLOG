﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Blog_DAL
{
    public class Person
    {
        [Key]
        public int Pid { get; set; }
        public string? Name { get; set; }
        public int? Age { get; set; }

    }

    public class Blog
    {
        [Key]
        public int BlogId { get; set; }
        public string BlogName { get; set; }

        [StringLength(1000)]
        public string BlogData { get; set; }

    }

    public class Viewer
    {
        [Key]
        public int Vid { get; set; }
        public string UserName { get; set; }
        public int? Age { get; set; }
    }

    public class Review
    {
        [Key]
        public int RevId { get; set; }


        [StringLength(500)]
        public string RevData { get; set; }

        public DateTime? RevTime { get; set; }
    }

    public class BlogDbContext : DbContext
    {
        public DbSet<Person> Person { get; set; }
        public DbSet<Blog> Blog {  get; set; }
        public DbSet<Viewer> Viewer { get; set; }
        public DbSet<Review> Review { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"server=(localdb)\MSSQLLocalDB;database=FinalBlog;trusted_connection=true");
        }
    }

}

