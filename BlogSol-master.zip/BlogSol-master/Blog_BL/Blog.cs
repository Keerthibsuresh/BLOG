﻿using Blog_DAL;
using Blog_BL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog_BL
{
    public class Blog
    {

        public int BlogId { get; set; }
        public string BlogName { get; set; }

        public string BlogData { get; set; }


        static BlogDbContext DbContext = new BlogDbContext();
        public static void Add(Blog_DAL.Blog b)
        {
            DbContext.Blog.Add(new Blog_DAL.Blog()
            {
                BlogName = b.BlogName,
                BlogData = b.BlogData,

            });
            DbContext.SaveChanges();

        }

        public static void Update(int BlogId, string BlogName, string BlogData)
        {
            var tbu = DbContext.Blog.ToList().
                   Where((b) => b.BlogId == BlogId).FirstOrDefault();
            tbu.BlogName = BlogName;
            tbu.BlogData = BlogData;
            
            DbContext.SaveChanges();
        }

        //public static bool Update(int BlogId, Blog Updatedblog)
        //{

        //    var found = GetAllblogs().Where(b => b.BlogId== b.BlogId).FirstOrDefault();
        //    if (found != null)
        //    {

        //        found.BlogId = Updatedblog.BlogId;
        //        found.BlogName = Updatedblog.BlogName;
        //        found.BlogData = Updatedblog.BlogData;


        //        return true;
        //    }

        //    else
        //        throw new Exception("No such record");

        //}

        public static void Delete(int BlogId)
        {
            var tbd = DbContext.Blog.ToList().
                Where((b) => b.BlogId == BlogId).FirstOrDefault();

            DbContext.Blog.Remove(tbd);
            DbContext.SaveChanges();


        }



        public static List<Blog_DAL.Blog> Get()
        {

            return DbContext.Blog.ToList();
        }
    }
}
    