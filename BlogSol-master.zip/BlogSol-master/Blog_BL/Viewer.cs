﻿using Blog_DAL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog_BL
{
    public class Viewer
    {
        public int Vid { get; set; }
        public string UserName { get; set; }
        public int Age { get; set; }


        static BlogDbContext DbContext = new BlogDbContext();
        public static Blog_DAL.Blog Search(string bname)
        {
            var tbu = DbContext.Blog
                   .ToList()
                   .Where((b) => b.BlogName == bname)
                   .FirstOrDefault();

            

            return tbu;
        }

        public static void AddViewer(Blog_DAL.Viewer V)
        {
            DbContext.Viewer.Add(new Blog_DAL.Viewer()
            {
                Vid = V.Vid,
                UserName = V.UserName,
                Age = V.Age

            });
            DbContext.SaveChanges();
        }

        public static void AddReview(Blog_DAL.Review R)
        {
            DbContext.Review.Add(new Blog_DAL.Review()
            {
                RevId=R.RevId,
                RevData = R.RevData,
                RevTime=R.RevTime
                

            });
            DbContext.SaveChanges();
           
        }

        public static void DeleteReview(int RevId)
        {
            var tbd = DbContext.Review.ToList().
                Where((b) => b.RevId == RevId).FirstOrDefault();

            DbContext.Review.Remove(tbd);
            DbContext.SaveChanges();


        }


    }
}
