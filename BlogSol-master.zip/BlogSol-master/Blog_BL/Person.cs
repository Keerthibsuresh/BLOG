﻿using Blog_DAL;
using Microsoft.EntityFrameworkCore;

namespace Blog_BL
{
    public class Person
    {
        public int Pid { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }

        static BlogDbContext DbContext= new BlogDbContext();
        public static void Add(Blog_DAL.Blog b)
        {
            DbContext.Blog.Add(new Blog_DAL.Blog()
            {
                BlogName = b.BlogName,
                BlogData = b.BlogData,
                
            });
            DbContext.SaveChanges();
        }

        public static void Update(int BlogId, Blog_DAL.Blog b)
        {
            var tbu = DbContext.Blog
                   .ToList()
                   .Where((p) => p.BlogId == BlogId)
                   .FirstOrDefault();
            tbu.BlogName = b.BlogName;
            tbu.BlogData = b.BlogData;
            
            DbContext.SaveChanges();
        }

        public static void Delete(int BlogId)
        {
            var tbd = DbContext.Blog.ToList().
                Where((b) => b.BlogId == BlogId).FirstOrDefault();

            DbContext.Blog.Remove(tbd);
            DbContext.SaveChanges();


        }
    }
}