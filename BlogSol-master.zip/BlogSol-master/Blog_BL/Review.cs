﻿using Blog_DAL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog_BL
{
    public class Review
    {
        public int RevId { get; set; }

        public string RevData { get; set; }

        public DateTime? RevTime { get; set; }

        static BlogDbContext DbContext = new BlogDbContext();

        public static void AddReview(Blog_DAL.Review R)
        {
            DbContext.Review.Add(new Blog_DAL.Review()
            {
                RevId = R.RevId,
                RevData = R.RevData,
                RevTime = R.RevTime

            });
            DbContext.SaveChanges();

        }
        public static void Delete(int RevId)
        {
            var tbd = DbContext.Review.ToList().
                Where((b) => b.RevId == RevId).FirstOrDefault();

            DbContext.Review.Remove(tbd);
            DbContext.SaveChanges();


        }
    }


}
