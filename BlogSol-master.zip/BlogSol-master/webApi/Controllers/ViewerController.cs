﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace webApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ViewerController : ControllerBase
    {

        private readonly ILogger<ViewerController> _logger;


        public ViewerController(ILogger<ViewerController> logger)
        {
            _logger = logger;
        }
        [HttpGet("Viewer")]
        public List<Blog_DAL.Blog> GetAllblogs()
        {
            var Blog = Blog_BL.Blog.Get();

            return Blog;
        }
        //[HttpGet("/search/{bname}")]
        //public IActionResult GetAllblogs([FromRoute] string bname)
        //{
        //    var Blog = Blog_DAL.Blog.Search(bname);
        //    return Ok(Blog);
        //}


        [HttpPost("addReview/{RId}/{RData}/{RTime}")]
        public IActionResult AddReview([FromRoute] int RId, [FromRoute] string RData, [FromRoute] DateTime RTime)
        {
            Blog_BL.Review.AddReview(new Blog_DAL.Review { RevId = RId, RevData = RData, RevTime = RTime  });
            return Ok("Added");
        }


        [HttpDelete("Delete/{RevId}")]
        public IActionResult DeleteReview([FromForm] int RevId)
        {
            Blog_BL.Review.Delete(RevId);
            return Ok("Deletion successful");

        }
        //[HttpPost("addViewer/{BId}/{BName}/{BData}")]
        //public IActionResult AddViewer([FromRoute] int VId, [FromRoute] string uname, [FromRoute] int age)
        //{
        //    Blog_BL.Viewer.Add(new Blog_DAL.Viewer { Vid = VId, UserName = uname, Age = age });
        //    return Ok("Added");
        //}


    }
}
