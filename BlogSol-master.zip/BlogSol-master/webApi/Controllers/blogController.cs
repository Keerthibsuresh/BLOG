﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using webApi.models;

namespace webApi.Controllers
{
    [Authorize]
    [Route("[controller]")]
    [ApiController]
    public class blogController : ControllerBase
    {
        private readonly ILogger<blogController> _logger;

       
            public blogController(ILogger<blogController> logger)
            {
                _logger = logger;
            }
            [HttpGet("Allblog")]
            //public IActionResult GetAllblogs()
            //{
               
            //    return Ok(BlogOperations.GetAllblogs());
            //}
            public List<Blog_DAL.Blog> GetAllblogs()
            {
                var Blog = Blog_BL.Blog.Get();

                return Blog;
            }



        [HttpPost("addBlog/{BId}/{BName}/{BData}")]
            public IActionResult AddBlog([FromRoute] int BId ,[FromRoute] string BName, [FromRoute] string BData)
            {
            Blog_BL.Person.Add(new Blog_DAL.Blog { BlogId= BId ,BlogName = BName, BlogData = BData });
                return Ok("Added");
            }

           

        [HttpPut("Update/{BlogId}")]
        public IActionResult Updateblog([FromForm]int BlogID, Blog_DAL.Blog b)
        {

           
               Blog_BL. Person.Update(BlogID, b);
                return Ok("Update successful");

          
        }

        [HttpDelete("Delete/{BlogId}")]
            public IActionResult DeleteBlog([FromForm] int BlogId )
            {
                    Blog_BL.Person.Delete(BlogId);
                    return Ok("Deletion successful");

            }
              
    }

} 


    



