﻿namespace webApi.models
{
    public class blog
    {
        public int BlogId { get; set; }
        public string BlogName { get; set; }

        public string BlogData { get; set; }
    }

        public class BlogOperations
        {
            private static List<blog> _blg = new List<blog>();

            public static int blogId { get; private set; }

            public static List<blog> GetAllblogs()
            {
                if (_blg.Count == 0)
                {
                    _blg.Add(new blog() { BlogId = 101, BlogName = "Sports", BlogData = "Sports is good for health" });

                }
                return _blg;
            }

        internal static blog Search(int bBlogId)
        {
            return GetAllblogs().Where(b => b.BlogId == bBlogId).FirstOrDefault();
        }

       

        public static void CreateNew(blog b)
        {
            GetAllblogs();
            _blg.Add(b);
        }

        public static bool Update(string BlogName , blog Updatedblog )
        {

            var found = GetAllblogs().Where(b => b.BlogName == b.BlogName).FirstOrDefault();
            if (found != null)
            {

                found.BlogName = Updatedblog.BlogName;
                found.BlogData = Updatedblog.BlogData;
                found.BlogId = Updatedblog.BlogId;


                return true;
            }

            else
                throw new Exception("No such record");

        }

        public static bool Delete(string pAadhar)
        {
            var found = GetAllblogs().Where(b => b.BlogName == b.BlogName).FirstOrDefault();
            if (found != null)
            {

                GetAllblogs().Remove(found);
                return true;

            }

            else
                throw new Exception("No such record");


        }

    }
}

